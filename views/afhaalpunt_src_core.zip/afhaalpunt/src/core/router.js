import { State } from "./state.js";
import { stopScanner } from "./scanner.js";

export function go(to){
  stopScanner();
  State.scanning = false;
  State.page = to;

  // Render hook (jij koppelt later je pages/roles)
  try{
    window.__renderApp?.();
  }catch(e){}
}

window.go = go;
