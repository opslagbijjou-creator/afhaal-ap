import { listenAuth } from "./auth.js";
import { State } from "./state.js";

// Core-only bootstrap: auth gate + render hook.
// Jij zet later window.__renderApp = (root)=>{...} in je app code.

listenAuth((user) => {
  if(!user){
    State.user = null;
    State.role = "medewerker";
    State.page = "login";
  }else{
    State.user = { email: user.email || "" };
    if(State.page === "login") State.page = "home";
  }

  try{
    window.__renderApp?.(document.getElementById("app"));
  }catch(e){}
});
