export const State = {
  user: null,            // {email}
  role: "medewerker",    // "medewerker" | "moderator"
  page: "home",
  scanning: false,

  // inbound batch carrier
  batchCarrier: null,

  // inbound form state
  inbound: {
    barcode: null,
    firstName: "",
    lastName: "",
    note: "",
    suggestedLoc: null,
    showManual: false,
    manual: { r:"", p:"", e:"", sub:"" },
  },

  // pickup state
  pickup: {
    query: { first:"", last:"" },
    list: [],
    selected: null,
  },
};
