# src/core
Dit mapje is de 'engine' van je webapp.

## Bestanden
- bootstrap.js  -> start app + auth gate
- auth.js       -> Firebase auth wrapper
- state.js      -> globale state
- router.js     -> simpele router (go('home'))
- shell.js      -> topbar + bottom nav + page container
- scanner.js    -> Quagga start/stop (camera)
- utils.js      -> helpers (toast, beep, formatting)
- config.js     -> carriers + moderator allowlist + defaults

## Belangrijk
Imports moeten ALTIJD relatief zijn (./ of ../), nooit beginnen met /.
