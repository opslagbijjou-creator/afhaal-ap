// Let op: dit bestand verwacht dat jij in de ROOT van je project `firebase.js` hebt
// die `export const auth = getAuth(app);` exporteert.

import { auth } from "../../firebase.js";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

export function listenAuth(cb){
  return onAuthStateChanged(auth, cb);
}

export async function login(email, password){
  return signInWithEmailAndPassword(auth, email, password);
}

export async function logout(){
  return signOut(auth);
}
